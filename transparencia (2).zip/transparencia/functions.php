<?php
/**
 * Transparencia Gob functions and definitions
 * 
 *
 * @package WordPress
 * @subpackage Transparencia Gob
 * @since Transparencia Gob 1.0
 */

require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/template-lib.php';
require get_template_directory() . '/inc/custom-post-type.php';
require get_template_directory() . '/inc/custom-fields.php';
require get_template_directory() . '/inc/customizer.php';


register_nav_menus( array(
	'primary' => 'Navegación Principal de Transparencia',
	'mobile' => 'Navegación Principal de Transparencia movil',
	'search-menu' => 'Navegación bajo el Buscador',	
	'footer'  => 'Navegación en el Pie de Página',
));
