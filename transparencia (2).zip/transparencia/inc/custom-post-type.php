<?php
/**
 * Customizer functionality
 *
 * @package WordPress
 * @subpackage Transparencia Gob
 * @since Transparencia Gob 1.0
 */
 
function add_transparencia_caps() {
    // gets the administrator role
    $admins = get_role( 'administrator' );
    //set permiso carpetas to administrator
    $admins->add_cap( 'edit_carpeta' );	
	$admins->add_cap( 'edit_carpetas' );
	$admins->add_cap( 'publish_carpetas' );
	$admins->add_cap( 'delete_carpeta' );	
    //set permiso documentos to administrator	
	$admins->add_cap( 'edit_documento' );	
	$admins->add_cap( 'edit_documentos' );
	$admins->add_cap( 'publish_documentos' );
	$admins->add_cap( 'delete_documento' );	
}
add_action( 'admin_init', 'add_transparencia_caps');


/**
 * Registers documentos post type.
 *
 * @link https://developer.wordpress.org/reference/functions/register_sidebar/
 *
 * @since Transparencia 1.0
 */
function register_documentos_post_type(){

	/* registrar taxonomía Carpetas */
	$labels = array(
		'name' => 'Carpeta',
		'singular-name' => 'Carpeta',
		'add_new' => 'Agregar Carpeta',
		'all_items' => 'Todas las Carpetas',
		'edit_item' => 'Editar Carpeta', 
		'view_item' => 'Ver Carpetas',
		'search_item' => 'Buscar Carpetas',
		'not_found' => 'Carpeta No Encontrada',
		'not_found_in_trash' => 'Carpeta no encontrada en su busqueda',
		'add_new_item'      => 'Agregar Carpeta',
		'new_item_name'     => 'Nueva Carpeta',
		'menu_name'         => 'Carpetas'
	);
	
	$args = array(
		'hierarchical'          => true,
		'labels'                => $labels,
		'show_ui'               => true,
		'show_admin_column'     => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var'             => true,
		'rewrite'               => array( 'slug' => 'carpeta' ),
	);
	
	register_taxonomy( 'carpeta','documento', $args );
	
	//register documentos
	$labels = array(
		'name' => 'Documentos',
		'singular-name' => 'Documento',
		'add_new' => 'Agregar Documento',
		'all_items' => 'Todos los Documentos',
		'edit_item' => 'Editar Documento',
		'new_item' => 'Nueva Documento',
		'view_item' => 'Ver Documentos',
		'search_item' => 'Buscar Documentos',
		'not_found' => 'Documento No Encontrado',
		'not_found_in_trash' => 'Documento no encontrado en su busqueda',		 
	);
	
	$args = array(
		'labels' => $labels,
		'description' => 'Documentos',
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'capability_type' => 'post',
		'capabilities' => array(
	        'edit_post' => 'edit_documento',
	        'edit_posts' => 'edit_documentos',
	        'publish_posts' => 'publish_documentos',
	        'delete_post' => 'delete_documento'
	    ),		
		'supports' => array('title','editor','thumbnail','page-attributes'),//revision		
		'taxonomies' => array('carpeta'),
		'menu_position' => 21,
		'menu_icon'   => 'dashicons-open-folder',
		'rewrite' => array(
            'slug'       => 'documento',
            'with_front' => false,
        ),
		'exclude_from_search' => false		
	);
	register_post_type("documento",$args);		
}
add_action('init',"register_documentos_post_type");

/**
 * Display a custom taxonomy dropdown in admin
 * @author Mike Hemberger
 * @link http://thestizmedia.com/custom-post-type-filter-admin-custom-taxonomy/
 */
function documento_filter_post_type_by_taxonomy() {
	global $typenow;
	$post_type = 'documento'; // change to your post type
	$taxonomy  = 'carpeta'; // change to your taxonomy
	if ($typenow == $post_type) {		
		$selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
		$info_taxonomy = get_taxonomy($taxonomy);		
		wp_dropdown_categories(array(
			'show_option_all' => sprintf( __( 'Todas las %s', 'textdomain' ), $info_taxonomy->label ),
			'taxonomy'        => $taxonomy,
			'name'            => $taxonomy,
			'orderby'         => 'name',
			'selected'        => $selected,
			'show_count'      => true,
			'hide_empty'      => true,
		));
	};
}
add_action('restrict_manage_posts', 'documento_filter_post_type_by_taxonomy');

/**
 * Filter posts by taxonomy in admin
 * @author  Mike Hemberger
 * @link http://thestizmedia.com/custom-post-type-filter-admin-custom-taxonomy/
 */
add_filter('parse_query', 'documento_convert_id_to_term_in_query');
function documento_convert_id_to_term_in_query($query) {
	global $pagenow;
	$post_type = 'documento'; // change to your post type
	$taxonomy  = 'carpeta'; // change to your taxonomy
	$q_vars    = &$query->query_vars;
	if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
		$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
		$q_vars[$taxonomy] = $term->slug;
	}
} 