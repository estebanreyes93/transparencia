<?php
/**
 * Unicaibe Customizer functionality
 *
 * @package WordPress
 * @subpackage Transparencia Gob
 * @since Transparencia Gob 1.0
 */

/**
 * Adds  support for site title and description for the Customizer.
 *
 * @since Twenty Sixteen 1.0
 *
 * @param WP_Customize_Manager $wp_customize The Customizer object.
 */
 function transparencia_customize_register( $wp_customize )
{

	$wp_customize->add_setting( 'info_backgound_header', array());

	$wp_customize->add_control( new WP_Customize_Upload_Control($wp_customize,'info_backgound_header', 
		array(
			'label'      => "Backgound header",
			'section'    => 'background_image',
			'settings'   => 'info_backgound_header',
		) ) 
	);	

	$wp_customize->add_setting( 'info_backgound_footer', array());

	$wp_customize->add_control( new WP_Customize_Upload_Control($wp_customize,'info_backgound_footer', 
		array(
			'label'      => "Backgound Footer",
			'section'    => 'background_image',
			'settings'   => 'info_backgound_footer',
		) ) 
	);	

	// Add color scheme setting and control.
	$wp_customize->add_setting( 'info_color_header', array( ) );
	$wp_customize->add_control( 
		new WP_Customize_Color_Control($wp_customize, 'info_color_header', 
		array(
			'label'      => __( 'Color de fondo del header' ),
			'section'    => 'colors',
			'settings'   => 'info_color_header',
		) ) 
	);

	$wp_customize->add_setting( 'info_color_footer', array( ) );
	$wp_customize->add_control( 
		new WP_Customize_Color_Control($wp_customize, 'info_color_footer', 
		array(
			'label'      => __( 'Color de fondo del Footer' ),
			'section'    => 'colors',
			'settings'   => 'info_color_footer',
		) ) 
	);

	$wp_customize->add_setting( 'info_logo_footer', array(		
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control( new WP_Customize_Upload_Control($wp_customize,'info_logo_footer', 
		array(
			'label'      => "Logo Footer",
			'section'    => 'title_tagline',
			'settings'   => 'info_logo_footer',
		) ) 
	);			

	$wp_customize->add_setting( 'info_menu_backgound_color', array( ) );
	$wp_customize->add_control( 
		new WP_Customize_Color_Control($wp_customize, 'info_menu_backgound_color', 
		array(
			'label'      => __( 'Color del Fondo del Menú Principal' ),
			'section'    => 'colors',
			'settings'   => 'info_menu_backgound_color',
		) ) 
	);

	$wp_customize->add_setting( 'info_color_link_text', array( ) );
	$wp_customize->add_control( 
		new WP_Customize_Color_Control($wp_customize, 'info_color_link_text', 
		array(
			'label'      => __( 'Color de enlaces' ),
			'section'    => 'colors',
			'settings'   => 'info_color_link_text',
		) ) 
	);

	$wp_customize->add_setting( 'info_color_link', array( ) );
	$wp_customize->add_control( 
		new WP_Customize_Color_Control($wp_customize, 'info_color_link', 
		array(
			'label'      => __( 'Color de enlaces activo' ),
			'section'    => 'colors',
			'settings'   => 'info_color_link',
		) ) 
	);
	
	$wp_customize->add_setting( 'info_color_info_footer', array( ) );
	$wp_customize->add_control( 
		new WP_Customize_Color_Control($wp_customize, 'info_color_info_footer', 
		array(
			'label'      => __( 'Color del texto del Footer' ),
			'section'    => 'colors',
			'settings'   => 'info_color_info_footer',
		) ) 
	);

	$wp_customize->add_setting( 'info_color_link_footer', array( ) );
	$wp_customize->add_control( 
		new WP_Customize_Color_Control($wp_customize, 'info_color_link_footer', 
		array(
			'label'      => __( 'Color sobre enlaces del footer' ),
			'section'    => 'colors',
			'settings'   => 'info_color_link_footer',
		) ) 
	);
	
	$wp_customize->add_setting( 'info_color_link_hover_footer', array( ) );
	$wp_customize->add_control( 
		new WP_Customize_Color_Control($wp_customize, 'info_color_link_hover_footer', 
		array(
			'label'      => __( 'Color sobre enlaces del footer' ),
			'section'    => 'colors',
			'settings'   => 'info_color_link_hover_footer',
		) ) 
	);
	        
	        
	$wp_customize->add_section( 'info_general_top' , array(
	    'title'      => "Información General",
	    'description'  => 'Información General de la Plantilla',
	    'capability'  => 'edit_theme_options',
	    'priority'   => 30,
	) );
	
	// Add title footer setting and control.
	$wp_customize->add_setting( 'info_title_footer', array(
		'default'           => '',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control('info_title_footer', 
		array(
			'label'    => "Título del pie de página",
			'section'  => 'info_general_top',
			'settings' => 'info_title_footer',
			'type'     => 'text'			
			)		
	);	

	// Add address footer setting and control.
	$wp_customize->add_setting( 'info_address', array(
		'default'           => '',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control('info_address', 
		array(
			'label'    => "Dirección",
			'section'  => 'info_general_top',
			'settings' => 'info_address',
			'type'     => 'text'			
			)		
	);	
 
	// Add phone setting and control.
	$wp_customize->add_setting( 'info_phone', array(
		'default'           => '(809) 000-0000',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control('info_phone', 
		array(
			'label'    => "Teléfono",
			'section'  => 'info_general_top',
			'settings' => 'info_phone',
			'type'     => 'text'			
			)		
	);	

	// Add fax setting and control.
	$wp_customize->add_setting( 'info_fax', array(
		'default'           => '(809) 000-0000',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control('info_fax', 
		array(
			'label'    => "Fax",
			'section'  => 'info_general_top',
			'settings' => 'info_fax',
			'type'     => 'text'			
			)		
	);	
	
	// Add mail setting and control.
	$wp_customize->add_setting( 'info_mail', array(
		'default'           => 'info@transparencia.gob.do',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control('info_mail', 
		array(
			'label'    => "Email de Contacto",
			'section'  => 'info_general_top',
			'settings' => 'info_mail',
			'type'     => 'text'			
			)		
	);  
	
	// Add Analytics setting and control.
	$wp_customize->add_setting( 'info_google_analytics', array(
		'default'           => '',
		'transport'         => 'postMessage',
	) );

	$wp_customize->add_control('info_google_analytics', 
		array(
			'label'    => "Google Analytics",
			'section'  => 'info_general_top',
			'settings' => 'info_google_analytics',
			'type'     => 'textarea'			
			)		
	);
	
	$section_description = 'Para agregar o modificar el número de Certificaciones debe seleccionar Ajustes de Certificaciones y configurar. 
							<br><br><i> Luego de modificar y publicar el número de Certificaciones debe actualizar la página para poder visualizar los cambios.</i>';
	// Add Nortic Panel
	$wp_customize->add_panel( 'info_nortic_certificaciones' , array(
	    'title'      => "Certificaciones Nortic",
		'description'  => $section_description,
		'capability'  => 'edit_theme_options',  
	    'priority'   =>40,
	) );	 
	
	// Add Nortic section
	$wp_customize->add_section( 'info_nortic', array(
		'title'      => "Ajustes de Certificaciones",
		'description'  => '<i> Luego modificar y publicar el número de Certificaciones debe actualizar la página para poder agregar.</i>',
		'capability'  => 'edit_theme_options',
		'panel'       => 'info_nortic_certificaciones',
		'priority'   => 10,
	) );
	
	// Add Nortic Links setting and control.
	$wp_customize->add_setting( 'nortic_link', array());
	$wp_customize->add_control('nortic_link', 
		array(
			'label'    => "Enlace de Certificaciones Nortic",
			'section'  => 'info_nortic',
			'settings' => 'nortic_link',
			'type'     => 'text'			
			)		
	);

	// Add Nortic num setting and control.
	$wp_customize->add_setting( 'nortic_num', array());
	$wp_customize->add_control('nortic_num',   
		array(
			'label'    => "Número de Certificaciones Nortic",
			'section'  => 'info_nortic',
			'settings' => 'nortic_num',
			'type'     => 'number'			
			)		
	);

	for($a = 1; $a <= get_theme_mod("nortic_num"); $a++){
		// Add Nortic section
		$wp_customize->add_section( 'info_nortic_' . $a, array(
			'title'      => empty(get_theme_mod("nortic_info_title_" . $a)) ? "Certificaciones Nortic $a" : get_theme_mod("nortic_info_title_" . $a),
			'description'  => '<i></i>',
			'capability'  => 'edit_theme_options',
			'panel'       => 'info_nortic_certificaciones',
			'priority'   => 12 * $a,
		) );
		
		// Add Nortic setting and control.
		$wp_customize->add_setting( 'nortic_info_title_' . $a, array());
		$wp_customize->add_control('nortic_info_title_' . $a, 
			array(
				'label'    => "Título Certificación Nortic " . $a,
				'section'  => 'info_nortic_' . $a,
				'settings' => 'nortic_info_title_' . $a,
				'type'     => 'text'			
				)		
		);

		// Add facebook setting and control.
		$wp_customize->add_setting( 'nortic_info_' . $a, array());
		$wp_customize->add_control('nortic_info_' . $a, 
			array(
				'label'    => "Enlace " . $a,
				'section'  => 'info_nortic_' . $a,
				'settings' => 'nortic_info_' . $a,
				'type'     => 'text'			
				)		
		);
	}

	// Add social section	
	$wp_customize->add_section( 'info_general_social' , array(
	    'title'      => "Redes Sociales",
	    'description'  => 'Información De Usuarios de Redes Sociales',
	    'capability'  => 'edit_theme_options',
	    'priority'   => 100,
	) );
	
	// Add facebook setting and control.
	$wp_customize->add_setting( 'info_facebook', array(
		'default'           => 'TransparenciaOnline',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control('info_facebook', 
		array(
			'label'    => "Usuario Facebook",
			'section'  => 'info_general_social',
			'settings' => 'info_facebook',
			'type'     => 'text'			
			)		
	);
	// Add twitter setting and control.
	$wp_customize->add_setting( 'info_twitter', array(
		'default'           => 'transparenciaonline',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control('info_twitter', 
		array(
			'label'    => "Usuario Twitter",
			'section'  => 'info_general_social',
			'settings' => 'info_twitter',
			'type'     => 'text'			
			)		
	);
	// Add instagrams setting and control.
	$wp_customize->add_setting( 'info_instagram', array(
		'default'           => 'transparenciaonline',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control('info_instagram', 
		array(
			'label'    => "Usuario Instagram",
			'section'  => 'info_general_social',
			'settings' => 'info_instagram',
			'type'     => 'text'			
			)		
	);
	// Add Youtube setting and control.
	$wp_customize->add_setting( 'info_youtube', array(
		'default'           => 'TransparenciaOnline',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control('info_youtube', 
		array(
			'label'    => "Usuario Youtube",
			'section'  => 'info_general_social',
			'settings' => 'info_youtube',
			'type'     => 'text'			
			)		
	);
}
add_action( 'customize_register', 'transparencia_customize_register' );