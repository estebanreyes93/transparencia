<?php
/**
 * Custom Post Type Transparencia
 *
 * @package WordPress
 * @subpackage Transparencia Gob
 * @since Transparencia Gob 1.0
 */

if ( ! function_exists( 'transparencia_support' ) ) :

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * @since Twenty Twenty-Two 1.0
 *
 * @return void
 */
function transparencia_support() {

    // Add support for block styles.
    add_theme_support( 'wp-block-styles' );

    // Enqueue editor styles.
    add_editor_style( 'style.css' );

    // Set up the WordPress core custom background feature.
    add_theme_support('custom-background', apply_filters('transparencia_custom_background_args', array(
        'default-color' => 'ffffff',
        'default-image' => '',
    )));

    // Add theme support for selective refresh for widgets.
    add_theme_support('customize-selective-refresh-widgets');

    /**
     * Add support for core custom logo.
     *
     * @link https://codex.wordpress.org/Theme_Logo
     */
    add_theme_support('custom-logo', array(
        'height'      => 250,
        'width'       => 250,
        'flex-width'  => true,
        'flex-height' => true,
    ));
}

endif;
add_action( 'after_setup_theme', 'transparencia_support' );