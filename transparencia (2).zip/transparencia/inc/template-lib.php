<?php
/**
 * Returns a list of all the breadcrumbs for the current page.
 * usage: apply_filters( 'my_get_breadcrumbs', false )
 *
 * @param $max_depth int
 *
 * @return string
 */
global $post;
function the_breadcrumbs($object = null, $text ="") {
	$crumbs = '';
	if(is_null($object)){
		$current_page_id = get_the_ID();
		$parent          = wp_get_post_parent_id( $current_page_id );
	}else{
		$crumbs = get_term_parents_list($object->term_id,$object->taxonomy);
		$crumbs = substr($crumbs,0,strlen($crumbs) - 2);
		$parent = false;
	}
	$index = 0;

	while ( $parent ) {
		$index ++;
		$crumbs = '<a href="' . get_permalink( $parent ) . '">' . get_the_title( $parent ) . '</a>/ ' . $crumbs;
		$parent = wp_get_post_parent_id( $parent );

		if ( $index > 10 ) {
			break;
		}
	}	
	
	$inicio = is_home() ? "<b>Inicio</b>" : 'Inicio / ';
	$name = !is_home() && is_null($object) ? "<a href=' '>".get_the_title( $current_page_id ) ."</a>": "";//$object->name
	if(!($text == ""))$name = $crumbs = "";
	$inicio = '<div class="breadcrumb1s">
		<span class="estasaqui">Estás aquí:&nbsp;</span>
		<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="">
			<span itemprop="name">'.$inicio.'</span>
			<meta itemprop="position" content="1">
		</span>
		'.$crumbs .  $name .$text.'
	</div>';
	
	return $inicio;
}
add_filter( 'my_get_breadcrumbs', [ $post, 'the_breadcrumbs' ], 10, 1 );

function formatBytes($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 

    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 

    // Uncomment one of the following alternatives
     $bytes /= pow(1024, $pow);
     //$bytes /= (1 << (10 * $pow)); 

    return round($bytes, $precision) . ' ' . $units[$pow]; 
} 

function formatDateStr($date){
	$meses = array("","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
	return date("d", $date) ." de ". $meses[date("n",$date)] ." ".date("Y", $date);	
}

function wpbeginner_numeric_posts_nav() {
  
	if( is_singular() )
			return;

	global $wp_query;

	/** Stop execution if there's only 1 page */
	if( $wp_query->max_num_pages <= 1 )
			return;

	$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
	$max   = intval( $wp_query->max_num_pages );

	/** Add current page to the array */
	if ( $paged >= 1 )
			$links[] = $paged;

	/** Add the pages around the current page to the array */
	if ( $paged >= 3 ) {
			$links[] = $paged - 1;
			$links[] = $paged - 2;
	}

	if ( ( $paged + 2 ) <= $max ) {
			$links[] = $paged + 2;
			$links[] = $paged + 1;
	}

	echo '<div class="navigation"><ul>' . "\n";

	/** Previous Post Link */
	if ( get_previous_posts_link() )
			printf( '<li>%s</li>' . "\n", get_previous_posts_link() );

	/** Link to first page, plus ellipses if necessary */
	if ( ! in_array( 1, $links ) ) {
			$class = 1 == $paged ? ' class="active"' : '';

			printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );

			if ( ! in_array( 2, $links ) )
					echo '<li>…</li>';
	}

	/** Link to current page, plus 2 pages in either direction if necessary */
	sort( $links );
	foreach ( (array) $links as $link ) {
			$class = $paged == $link ? ' class="active"' : '';
			printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
	}

	/** Link to last page, plus ellipses if necessary */
	if ( ! in_array( $max, $links ) ) {
			if ( ! in_array( $max - 1, $links ) )
					echo '<li>…</li>' . "\n";

			$class = $paged == $max ? ' class="active"' : '';
			printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
	}

	/** Next Post Link */
	if ( get_next_posts_link() )
			printf( '<li>%s</li>' . "\n", get_next_posts_link() );

	echo '</ul></div>' . "\n";

}