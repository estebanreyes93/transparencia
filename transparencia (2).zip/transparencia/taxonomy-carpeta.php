<?php

get_header();

$taxonomy = get_queried_object();
?>
<section class="ree tContent">
    <div class="miga">
        <div class="breadcrumb1s">
            <?= the_breadcrumbs($taxonomy) ?>
        </div>
    </div>
    <h1 class="the_title"><?= $taxonomy->name ?></h1>

    <?php if(!empty(get_field("imagen_de_cabecera"))){ ?>
        <div class="cover">
            <p><img loading="lazy" class="alignnone" src="<?= get_field("imagen_de_cabecera") ?>"></p>
        </div>
    <?php } ?>

    <div class="cover">
        <?= get_field("contenido", $taxonomy); ?>
    </div>

    <div class="pd-category">
        <div class="los-folders">
            <?php
            $emptyFolder = 0;
            $childIDs = array();
            //Get Carpetas Hijas
            $children = get_terms(array(
                'taxonomy' => $taxonomy->taxonomy,
                'parent' => $taxonomy->term_id,
                'orderby' => 'slug',
                'order' => 'ASC',
                'hide_empty' => false
            ));
            
            if (!empty($children)) {
                foreach ($children as $child) {    
                    //remove if need optimization
                    $foldersChild = count(get_term_children($child->term_id, $child->taxonomy));                     
                    $childIDs[] = $child->term_id; ?>
                    <div>
                        <a id="carpeta-<?= $child->id ?>" href="<?= home_url() ?>/carpeta/<?= $child->slug ?>">
                            <div class="el-folder">
                                <div class="icon-folder float-left"></div>
                                <div><span class="title"><?= $child->name; ?></span>
                                    <div class="datos"><span class="date">
                                        <?php if($foldersChild > 0){ ?><b><?= $foldersChild ?></b> Carpeta<?= $foldersChild == 1 ? "" :"s" ?></span><span class="date"></span><?php }else{ ?>
                                            <b><?= $child->count ?></b> Archivo<?= $child->count == 1 ? "" : "s"; ?></span><span class="date"></span>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>                    
            <?php }
            } else $emptyFolder++;
            ?>
        </div>

        <div class='attachment__container'>
            <?php
            //Get Documents In Folder
            $termChildren = $childIDs;
            $args = array(
                'post_type'        => 'documento',
                'post_status'      => 'publish',
                'orderby'          => 'menu_order',
                'order'            => 'ASC',
                'paged' => get_query_var( 'paged' ),
                'tax_query' => array(
                    array(
                        'taxonomy' => $taxonomy->taxonomy,
                        'field'    => 'slug',
                        'terms'    => $taxonomy->slug,
                    ),
                    array(
                        'taxonomy' => $taxonomy->taxonomy,
                        'field'    => 'term_id',
                        'terms'    => $termChildren,
                        'operator' => 'NOT IN'
                    )
                )
            );

            $documents = new WP_Query($args);
            if ($documents->have_posts()) : ?>

                <?php while ($documents->have_posts()) : $documents->the_post();
                    get_template_part( 'template-parts/document', 'post' );
                endwhile; ?>

                <div class="d-none d-sm-block d-md-block d-lg-block">
                    <a href="//get.adobe.com/es/reader/" target="_blank" class="adobe d-none d-sm-block" aria-label="Descarga Adobe Reader">
                        <img src="<?= get_template_directory_uri() ?>/assets/img/adobe.svg" alt="Descarga Adobe Reader">
                    </a>
                </div>
                
                <?php  wpbeginner_numeric_posts_nav(); ?>
            <?php else : $emptyFolder++;
            endif; ?>
        </div>

        <?php if ($emptyFolder == 3) { ?>
            <div class="empty-folder">No existe contenido que mostrar</div>
        <?php } ?>
        
        <div class="before-documents">
            <?= get_field("before_documents", $taxonomy); ?>
        </div>
</section>

<?php get_footer(); ?>