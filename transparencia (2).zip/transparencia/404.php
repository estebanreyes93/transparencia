<?php
/**
 * The template for displaying 404 pages (Not Found)
 */
?>
<?php get_header(); ?>
<section class="ree tContent">
	<div class="bt-default-page bt-404-page bt-main-row">
		<div class="container">
			<div class="row">

				<div class="content-area ">
					<div class="wrap-entry-404 text-center">
						<h1 class="entry-title fw-title-404"><?php esc_html_e( '404', '' ); ?></h1>
						<h3 class="entry-title fw-title-404-sub"><?php esc_html_e( 'Ohh! Page not found', 'alone' ); ?></h3>
						
					</div>
				</div><!-- /.content-area-->
	
			</div><!-- /.row-->
		</div><!-- /.container-->
	</div>
</section>

<?php get_footer(); ?>
