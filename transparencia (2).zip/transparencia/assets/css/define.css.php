<style type="text/css" media="all">
:root {
    --body-bg-color: <?= get_theme_mod("color") ?>;
    --header-bg-color: <?= get_theme_mod("info_color_header") ?>;
    --footer-bg-color: <?= get_theme_mod("info_color_footer") ?>;
    --menu-bg-color: <?= empty(get_theme_mod("info_menu_backgound_color")) ? '#FFF' : get_theme_mod("info_menu_backgound_color") ?>;
    --link-color-text:  <?= get_theme_mod("info_color_link_text") ?>;
    --link-color: <?= get_theme_mod("info_color_link") ?>;
    --header-bg: url(<?= get_theme_mod("info_backgound_header") ?>);
    --footer-info-color: <?= get_theme_mod("info_color_info_footer") ?>;    
    --footer-bg: url(<?= get_theme_mod("info_backgound_footer") ?>);    
    --footer-link-color: <?= get_theme_mod("info_color_link_footer") ?>;
    --footer-link-color-hover: <?= get_theme_mod("info_color_link_hover_footer") ?>;
}
</style>
  