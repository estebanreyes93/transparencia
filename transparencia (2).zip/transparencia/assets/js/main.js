/* Main Scrint */

document.querySelector("#scrollTop").addEventListener("click", (event) => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

document.querySelector(".btnMobile").addEventListener("click", (event) => {
  document.querySelector(".la-menu").classList.toggle("d-none");
});
