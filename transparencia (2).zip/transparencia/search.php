<?php get_header(); ?>
 
<section class="ree tContent">
	<div class="miga">            
		<?= the_breadcrumbs(null,"Resultados de búsqueda") ?> 
	</div>
	<div id="search-result-container" class="section-container">
		<h1 class="section-title">Resultados para: <span class="query-text"><?= get_search_query() ?></span></h1>
		<span class="tag-result"><?= count($posts); ?></span> Resultados encontrados			
		<hr>

		<div class="section-container">
			<?php 								
				if (have_posts()) : ?>
				<?php
					while (have_posts()) : the_post(); 
						if(get_post_type() == "documento"){
							get_template_part( 'template-parts/document', 'search' );
						}else{
							get_template_part( 'template-parts/content', 'search' );
						}						
					endwhile; 					
				endif;				
			?>			
		</div><!--end section-container-->
	</div><!--end search-result-container-->
</section><!--end main-container-wrap-->

<?php get_footer(); ?>