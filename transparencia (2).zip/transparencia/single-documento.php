<?php

get_header();

while (have_posts()) : the_post(); ?>
    <section class="ree tContent">
        <div class="miga">
            <div class="breadcrumb1s">
                <span class="estasaqui">Estás aquí:&nbsp;</span>
                <?= the_breadcrumbs() ?>
                <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="current-item">
                    <span itemprop="name">
                        Inicio </span>
                    <meta itemprop="position" content="1">
                </span>
            </div>
        </div>
        <h1 class="the_title"><?= the_title() ?></h1>
  
        <div class="control">
            <script type="text/javascript" src="../../s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5b2a95135b7f0c9b" async></script>
            <div class="tools">
                <div class="addthis_inline_share_toolbox"></div>
            </div>
        </div>

        <article id="page-<?php the_ID(); ?>" class="post post-details" itemscope="itemscope" itemtype="http://schema.org/BlogPosting" itemprop="blogPost">
            <div class="itemFullText">
                <div class="entry-content" itemprop="text">
                    <?php
                    the_content();
                    wp_link_pages(array(
                        'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__('Pages:', 'alone') . '</span>',
                        'after'       => '</div>',
                        'link_before' => '<span>',
                        'link_after'  => '</span>',
                    ));
                    ?>
                </div><!-- /.entry-content -->
            </div> 
        </article>
    </section>          
<?php endwhile;

get_footer(); ?>