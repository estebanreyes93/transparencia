<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta name="theme-color" content="#2055a2" />
    <meta charset="<?php bloginfo('blogname'); ?>">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?= bloginfo('blogdescription') ?>">
    <meta name="generator" content="Wordpress" />
    <meta name="keywords" content="transparencia,portal,gob">
    <meta name="title" content="Bienvenidos al Portal de Transparencia de la Autoridad Nacional de Asuntos Marítimos, (ANAMAR)." />
    <meta name="author" content="Ogtic Portals Teams" />
    <meta property="og:url" content="index.html" />
    <meta property="og:title" content="<?= bloginfo('blogname') ?>" />
    <meta property="og:type" content="article" />
    <meta property="og:description" content="<?= bloginfo('blogdescription') ?>" />
    <title><?= bloginfo('blogname') ?></title>

    <?php wp_head(); ?>

    <link id="bootstrap-style" rel="stylesheet" href="<?= get_template_directory_uri() . '/assets/css/bootstrap.min.css?v=1' ?>" type="text/css" media="all">
    <link id="bootstrap-style" rel="stylesheet" href="<?= get_template_directory_uri() . '/assets/css/icons-fa.css?v=1' ?>" type="text/css" media="all">  
    <?php include_once get_template_directory() . '/assets/css/define.css.php' ?>
    <link id="transparencia-style" rel="stylesheet" href="<?= get_template_directory_uri() . '/assets/css/styles.css?v=1.1' ?>" type="text/css" media="all">
    <link id="custom-transparencia-style" rel="stylesheet" href="<?= get_template_directory_uri() . '/assets/css/custom.css?v=1.2' ?>" type="text/css" media="all">  
    <link href="index.html" rel="canonical">
</head>

<body <?php body_class(); ?> itemscope="itemscope" itemtype="http://schema.org/WebPage">



    <header id="top">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-9 col">
                    <div class="logo">
                        <a href="<?= home_url() ?>" class="d-lg-block">
                            <div class="custom-logo-content">
                                <?php
                                $custom_logo_id = get_theme_mod('custom_logo');
                                if ($custom_logo_id > 0) {
                                    $image = wp_get_attachment_image($custom_logo_id, 'full portal_logo', false);
                                    print $image;
                                } else { ?>
                                   
                                    <a href="<?= home_url() ?>" class="default-logo">
                                       <object data=" <?php echo get_theme_file_uri('/assets/img/LOGO_GOB_centro_azul.svg') ?> " width=300 class='d-lg-none' ></object>
                                       <object data=" <?php echo get_theme_file_uri('/assets/img/LOGO_GOB_hor_azul.svg') ?>" width=300 class='d-none d-lg-block' ></object>
                                       <p class='default-logo-text d-none d-lg-block'>
                                           <span class="cls-2"><?= bloginfo('blogname') ?></span>
                                           <span>&nbsp;|&nbsp;Portal de Transparencia</span>
                                       </p>
                                       <p class='default-logo-text d-flex flex-column justify-content-center d-lg-none '>
                                           <span class="cls-2"><?= bloginfo('blogname') ?></span>
                                           <span>Portal de Transparencia</span>
                                       </p>
                                    </a>
                                <?php } ?>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-3 d-lg-none">
                    <button type="button" name="button" class="btn btnMobile">
                        <i class="fa fa-bars" aria-hidden="true"></i>
                    </button>
                </div>
                <div class="col-lg-3 col-md-3 d-none d-lg-block">
                    <div class="eletop float-right">
                        <div class="escudo">
                            <img src="<?= get_template_directory_uri() ?>/assets/img/header/escudo.svg" />
                        </div>
                        <div class="search">
                            <form class="search" action="<?= get_site_url() ?>" method="get" validate role="search">
                                <span class="input-la input-group">

                                    <input required name="s" maxlength="200" class="search-input form-control" type="search" placeholder="Ingresa tu búsqueda" />
                                    <span class="input-group-btn">
                                        <button class="search-submit" onclick=" this.form.searchword.focus();">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </button>
                                    </span>   
                                </span>
                            </form>

                        </div>
                        <div class="buscador menuTop">
                            <?php
                            if (has_nav_menu('search-menu')) :
                                wp_nav_menu(array(
                                    'theme_location' => 'search-menu',
                                    'menu_class'     => 'list-menu',
                                ));
                            endif;
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>


    <div class="controles_m d-lg-none d-block">
        <div class="row no-gutters align-items-center justify-content-between">
                <figure class="escudo-mobil col-3">
                    <img src="<?= get_theme_file_uri('assets/img/escudo.svg') ?>" />
                </figure>
                <div class="m-search col-9">
                    <form class="search" action=" <?= get_site_url() ?>" method="get" validate role="search">
                        <span class="input-la input-group">

                            <input required name="s" maxlength="200" class="search-input form-control" type="search" placeholder="Ingresa tu búsqueda" />
                            <span class="input-group-append">
                                <button class="search-submit btn" onclick=" this.form.searchword.focus();">
                                        <i class="fa fa-search" aria-hidden="true"></i>
                                </button>
                            </span>
                            <span class="input-group-btn"></span> 
                            <input type="hidden" name="task" value="search" />
                        </span>
                    </form>

                </div>
                <?php /*
                <div class="col-3">
                    <button type="button" name="button" class="btn btnMobile">
                        <i class="fa fa-bars" aria-hidden="true"></i>
                    </button>
                </div>
                */ ?>

        </div>
    </div>

    <div class="page">
        <div class="bg-top-content"></div>
        <main role="main" class="container">
            <div class="row no-gutters">
                <aside class="col d-none d-lg-block la-menu">
                    <div class="d-lg-block d-none">
                        <?php
                        if (has_nav_menu('primary')) :
                            wp_nav_menu(array(
                                'theme_location' => 'primary',
                                'menu_class'     => 'list-menu',
                                'depth'          => 2,
                            ));
                        endif;
                        ?>
                    </div>
                    <div class='d-block d-lg-none'>
                        <?php
                        if (has_nav_menu('mobile')) :
                            wp_nav_menu(array(
                                'theme_location' => 'mobile',
                                'menu_class'     => 'list-menu',
                                'depth'          => 2,
                            ));
                        endif;
                        ?>
                        
                    </div>

                </aside>
                <div class="col-lg-8">