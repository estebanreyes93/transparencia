<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 */

 function print_sellos_nortic($inline = false){ ?>
    <div id="sellos" class="visible-lg visible-md">                        
        <div id="<?= $inline ? "sellos-inline" :"sellos04" ?>" class="<?= $inline ? "" :"sellos" ?>">
            <?php for($a = 1; $a <= get_theme_mod("nortic_num"); $a++){ ?>
            <div class="stamp">
                <a href="<?= get_theme_mod("nortic_link") ?>" target="_blank"
                    title="<?= get_theme_mod('nortic_info_title_' . $a) ?>"></a>
                <div>
                    <iframe src="<?= get_theme_mod('nortic_info_' . $a) ?>" height="120"
                        width="120" frameborder="0" scrolling="no"> </iframe>
                </div>
            </div> 
            <?php } ?>
        </div>
    </div> 
 <?php }
?>

		</div><!-- /.site-main --> 
	</main>
</div><!-- /#page -->

	<section class="x-enlaces d-none d-sm-none d-md-block d-lg-block">
        <div class="enlaces">
            <div class="container">

                <img class="logo-e" src="<?= get_template_directory_uri() ?>/assets/img/enlaces.png"
                    alt="Escudo de la República Dominicana" />

                <div class="top-link">
                    <div class="row justify-content-center">
                        <div class='col-lg-3 col-6'>
                            <a target='_blank' class="inst-url" href='http://presidencia.gob.do/'>
                                <div class="item" style="display: flex;flex-direction: column;align-items: flex-end;">
                                    <span class="inst-name">Presidencia de la República</span>
                                    <span class='inst-link'>www.presidencia.gob.do</span>
                                </div>
                            </a>
                        </div>
                        <div class='col-lg-3 col-6'>
                            <a target='_blank' class="inst-url" href='http://vicepresidencia.gob.do/'>
                                <div class="item">
                                    <span class="inst-name">Vicepresidencia de la República</span>
                                    <span class='inst-link'>www.vicepresidencia.gob.do</span>
                                </div>
                            </a>
                        </div>
                        <div id="selectorenelcentro" class="col-lg-12">
                            <label for="changeLinks">
                                <span hidden>Enlaces a instituciones</span>
                                <select id="changeLinks" class="selector" aria-label="Selecciona una opción">
                                    <option value="ans1">Ministerios</option>
                                    <option value="ans2">Centros de Salud y Hospitales</option>
                                    <option value="ans3">Organismos Descentralizados</option>
                                    <option value="ans4">Otros</option>
                                </select>

                            </label>
                        </div>
                    </div>

                    <div id="response" class="row"></div>
                </div>
                <script type="text/javascript">
                    const loadLinks = (value='ans1') => {
                    return new Promise((resolve,response) => {
                        const requestInfo = new FormData;
                        const url = "//ogtic.gob.do/linka/v3/links.php";
                        requestInfo.append('action','getLinks');
                        requestInfo.append('value', value);
                        const linksText = fetch(url, {method: 'POST', body: requestInfo})
                            .then(response => response.text())
                            .then(links => links);
                        resolve(linksText);
                    })
                    }
                    const options = document.querySelector('#changeLinks');
                    const divResponse = document.querySelector('#response');
                    window.addEventListener('load',  event => {loadLinks(event.target.value).then(links=> { divResponse.innerHTML = links});})
                    options.addEventListener('change', event => {loadLinks(event.target.value).then(links=> { divResponse.innerHTML = links});});
                </script>
            </div>
        </div>
    </section>
    <!-- Fin Enlaces a instituciones -->
    <style>
        .gallery .g-container .mosaiquitos .slimbox:hover:after {
            background: #0293d28a;
        }

        .gallery .btn {
            border-color: #0293d2;
            color: #0293d2;
        }

        .gallery .btn:hover {
            background-color: #0293d2;
            box-shadow: 3px 3px 21px #0293d229;
            color: white;
        }
    </style>

    <footer>
        <aside class="d-lg-block d-none">
            <div class="container">
                <div id="scrollTop" href="#" class="toTop" title="Subir al Inicio"><i class="fas fa-angle-up"></i></div>
            </div>
        </aside>

        <div class="container d-none d-lg-block">
            <div class="row justify-content-end footer-info-logo">
                <div class="col-lg-6 justify-content-center d-sm-flex flex-column align-items-center">
                    <a href="<?= home_url() ?>" class="logos-footer">
                        <?php /*
                        <div class="logo-footer-institucional">
                            <a href="http://presidencia.gob.do/" target="_blank" rel="noopener">
                                <img src="<?= get_template_directory_uri() ?>/assets/img/presidencia.png" alt="Presidencia">
                            </a>
                        </div> 
                        

                        <div class="logo-footer-escudo">
                        */ ?>
                        <?php $logo_footer = get_theme_mod('info_logo_footer') ? get_theme_mod('info_logo_footer') : get_theme_file_uri('assets/img/LOGO_GOB_cupula_azul.svg'); ?>
                            <img class="logo-footer" src="<?= $logo_footer ?>" alt="Logo">
                        <?php /*</div> */ ?>
                    </a>
                <div class="footer-info">
                        <span class="ins-name"><?= get_theme_mod("info_title_footer") ?></span>
                        <address><?= get_theme_mod("info_address") ?></address>

                        <div class="contact-info">
                            Tel.: <?= get_theme_mod("info_phone") ?>
                            | Fax - <?= get_theme_mod("info_fax") ?>
                            <br>
                            <a class="info-mail" href="mailto:<?= get_theme_mod("info_mail") ?>?subject=<?= get_theme_mod("info_title_footer") ?>"><?= get_theme_mod("info_mail") ?></a>
                        </div>

                        <div class="menu-footer">
                         <?php
                            if (has_nav_menu('footer')) :
                                wp_nav_menu(array(
                                    'theme_location' => 'footer',
                                    'menu_class'     => 'list-menu',
                                ));
                            endif;
                         ?>
                    </div>
                        </div>

                        <div class="copyrigt">©<?= date("Y",time()) ?> Todos los derechos reservados</div>
                    </div>
                
                <div class="col-lg-3 d-none d-lg-block" style="padding-top: 25px;">
                    <?php if( get_theme_mod("nortic_num") < 5) print_sellos_nortic(); ?>                    
                </div>                
            </div>

            <?php if( get_theme_mod("nortic_num") >= 5) { ?>
                <div class="col-lg-12 d-none d-lg-block">
                    <?php print_sellos_nortic(true); ?>
                </div>
            <?php } ?> 
        </div>

        <!-- Footer Movil -->
        <div class="col d-block d-lg-none">
            <div class="mobile">
                <div class="custom">
                    <h4><b><?= get_theme_mod("info_title_footer") ?></b></h4>
                    <div class="menu-footer">
                    <?php
                            if (has_nav_menu('footer')) :
                                wp_nav_menu(array(
                                    'theme_location' => 'footer',
                                    'menu_class'     => 'list-menu',
                                ));
                            endif;
                    ?>
                    <?php /*
                        <ul>
                            <li class="item-138 current active"><a href="index-2.html">Inicio</a></li>
                            <li class="item-139"><a href="index.php/mapa-de-sitio.html">Mapa de sitio</a></li>
                            <li class="item-140"><a href="https://anamar.gob.do/index.php/contacto" target="_blank"
                                    rel="noopener noreferrer">Contacto</a></li>
                        </ul>
                        */ ?>
                    </div>

                    <div class="m-top">
                        <a href="#top"><i class="fa fa-arrow-up" aria-hidden="true"></i> SUBIR</a>
                    </div>
                    <address><?= get_theme_mod("info_address") ?></address>
                    <div class="contact-info">
                            Tel.: <?= get_theme_mod("info_phone") ?>
                            | Fax - <?= get_theme_mod("info_fax") ?>
                            <br>
                            <a class="info-mail" href="mailto:<?= get_theme_mod("info_mail") ?>?subject=<?= get_theme_mod("info_title_footer") ?>"><?= get_theme_mod("info_mail") ?></a>
                        </div>

                    <div class="sello">
                        <p><?php if(get_theme_mod("nortic_num") * 1  > 0) print "Portal web certificado bajo la NORTIC A2"; ?> </p>
                    </div>

                    <div class="caption">©<?= date("Y",time()) ?> Todos los derechos reservados.</div>
                    <div class="caption">República Dominicana</div>
                </div>
            </div>
        </div>
        </div> 
    </footer>

<?php wp_footer(); ?>  

<script src="<?= get_template_directory_uri() . '/assets/js/main.js?v=1' ?>" type="text/javascript" defer=""></script>
<script src="<?= get_template_directory_uri() . '/assets/js/custom.js?v=1' ?>" type="text/javascript" defer=""></script>
<script type="text/javascript"><?= get_theme_mod("info_google_analytics") ?></script>

</body>  
</html>