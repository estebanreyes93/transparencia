<?php
/*
	Template Name: Página Principal
*/
get_header();
global $post; 

while (have_posts()) : the_post(); ?>
    <section class="ree tContent">
        <div class="miga">            
            <?= the_breadcrumbs() ?>
        </div>
        <h1 class="the_title"><?= the_title() ?></h1> 

        <?php if(!empty(get_field("imagen_de_cabecera_pagina"))){ ?>
            <div class="cover">
                <p><img loading="lazy" class="alignnone" src="<?= get_field("imagen_de_cabecera_pagina") ?>"></p>
            </div>
        <?php } ?>
        
        <article id="page-<?php the_ID(); ?>" class="post post-details" itemscope="itemscope" itemtype="http://schema.org/BlogPosting" itemprop="blogPost">
            <div class="itemFullText">                
                <div class="entry-content" itemprop="text">
                    <?php
                    the_content();
                    wp_link_pages(array(
                        'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__('Pages:', 'alone') . '</span>',
                        'after'       => '</div>',
                        'link_before' => '<span>',
                        'link_after'  => '</span>',
                    ));
                    ?>
                </div><!-- /.entry-content -->
            </div> 
        </article>
    </section>          
<?php endwhile;

get_footer(); ?>