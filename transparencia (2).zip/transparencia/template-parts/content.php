
<?php  $content = get_the_content(); ?>

<div id="post-<?php the_ID() ?>" class="post-<?php the_ID() ?> page type-page status-publish hentry">
    <div class="rirem" style="padding-bottom: 45px !important;">
        <a href="<?php the_permalink() ?>" title="<?php the_title() ?>">
            <h2 class="title"><?php the_title() ?></h2>
            <div class="deta">
                <?= wp_trim_words($content, 60,"...") ?>
            </div>
            <div class="date d-none d-sm-block d-md-block d-lg-block" style="float:right">
                <span class="file-date">
                    <span class="calendar" style=" margin-top: 0px; "></span>
                    <span style=" padding-left: 27px; "><?= formatDateStr(strtotime(get_the_date("Y/m/d"))) ?> </span>
                </span>
            </div>
        </a>
    </div>
</div>