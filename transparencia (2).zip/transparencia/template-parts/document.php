<?php
$file = (object)get_field("archivo");
$type = "";
if (isset($file->url)) {
    $url = $file->url;
    $type = substr($url, strrpos($url, ".") + 1, strlen($url));
} else $url = "#";
?>
<div id="page-<?php the_ID(); ?>" class="attachment__container_item">
    <div class="the-icon">
        <div class="icon float-left document-type type-<?= $type ?>" alt="Icon .<?= $type ?>"></div>
    </div>
    <div class="the-caption">
        <div class="title">
            <span class="text"><?php the_title(); ?></span>
            <?php //the_content(); 
            ?>
            <?php if (!($url == "#")) { ?>
                <div class="file-size">
                    <span class="file-date">
                        <span class="calendar"></span>
                        <span style=" padding-left: 27px; "><?= formatDateStr(strtotime($file->modified)) ?>, </span>
                    </span>
                    <?= formatBytes($file->filesize); ?>
                </div>
            <?php } ?>
        </div>
    </div>

    <div class="the-btn">
        <?php /*
        <a class="info" href="#">
            <i class="icon-info">i</i>
            <div class="document-info">
                <span class="info-file info-type-<?= $type ?>">
                    <div class="file-name"><b>Nombre: </b><br><?= $file->filename ?></div>
                    <div class="file-size"><b>Tamaño: </b><br><?= formatBytes($file->filesize); ?></div>
                    <div class="file-date"><b>Fecha: </b><br><?= $file->modified ?></div>                                                                                                            
                </span>
            </div>
        </a>
        */ ?>
        <a class="btn-descargar" target="_blank" href="<?= $url ?>">Descargar</a>
    </div>
</div>